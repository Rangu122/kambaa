# Smart Daily Life Manager — React Web (Demo)
This is a feature-complete demo for the Smart Daily Life Manager (frontend-only).
Features:
- Mock auth (register/login) using localStorage
- Grocery lists (add, mark purchased, delete)
- Daily expenses (add with optional receipt image -> stored as base64)
- Notes & reminders (save text and optional reminder time)
- Travel history (add receipts and trip details)
- Groups (create and view shared items)
- All data stored per-user in localStorage for demo/hackathon

## Run locally
1. `npm install`
2. `npm run dev`
3. Open the URL printed by Vite (usually http://localhost:5173 or 5174)

