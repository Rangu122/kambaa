import React, { useEffect, useState } from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import Auth from './components/Auth'
import Groceries from './components/Groceries'
import Expenses from './components/Expenses'
import Notes from './components/Notes'
import Travels from './components/Travels'
import Groups from './components/Groups'
import Profile from './components/Profile'

function Nav({ user, onLogout }) {
  return (
    <div className="header">
      <div>
        <h1>Smart Daily Life Manager</h1>
        <div className="muted small">Manage groceries, expenses, notes, travel & family sharing</div>
      </div>
      <div style={{display:'flex',alignItems:'center',gap:10}}>
        <nav className="nav">
          <Link to="/groceries">Groceries</Link>
          <Link to="/expenses">Expenses</Link>
          <Link to="/notes">Notes</Link>
          <Link to="/travels">Travels</Link>
          <Link to="/groups">Groups</Link>
          <Link to="/profile">Profile</Link>
        </nav>
        {user ? (
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <div className="muted small">Hi, {user.name}</div>
            <button className="btn" onClick={onLogout}>Logout</button>
          </div>
        ) : <Link to="/auth"><button className="btn">Login / Register</button></Link>}
      </div>
    </div>
  )
}

export default function App(){
  const [user, setUser] = useState(null)
  const navigate = useNavigate()

  useEffect(()=> {
    const u = JSON.parse(localStorage.getItem('sdm_user')||'null')
    setUser(u)
  },[])

  const onLogin = (u) => {
    localStorage.setItem('sdm_user', JSON.stringify(u))
    setUser(u)
    navigate('/groceries')
  }
  const onLogout = () => {
    localStorage.removeItem('sdm_user')
    setUser(null)
    navigate('/auth')
  }

  return (
    <div className="app">
      <Nav user={user} onLogout={onLogout} />
      <div className="card">
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/auth" element={<Auth onLogin={onLogin} />} />
          <Route path="/groceries" element={<RequireAuth user={user}><Groceries user={user} /></RequireAuth>} />
          <Route path="/expenses" element={<RequireAuth user={user}><Expenses user={user} /></RequireAuth>} />
          <Route path="/notes" element={<RequireAuth user={user}><Notes user={user} /></RequireAuth>} />
          <Route path="/travels" element={<RequireAuth user={user}><Travels user={user} /></RequireAuth>} />
          <Route path="/groups" element={<RequireAuth user={user}><Groups user={user} /></RequireAuth>} />
          <Route path="/profile" element={<RequireAuth user={user}><Profile user={user} onLogout={onLogout} /></RequireAuth>} />
        </Routes>
      </div>
    </div>
  )
}

function Home({user}){
  if(!user) return (
    <div>
      <h2>Welcome!</h2>
      <p className="muted">Please login or register to continue.</p>
      <Link to='/auth'><button className="btn">Get Started</button></Link>
    </div>
  )
  return (
    <div>
      <h2>Dashboard</h2>
      <p className="muted">Use the navigation to access features.</p>
    </div>
  )
}

function RequireAuth({user, children}){
  if(!user) return <div><p className="muted">You must be logged in to access this page. <Link to='/auth'>Login</Link></p></div>
  return children
}
