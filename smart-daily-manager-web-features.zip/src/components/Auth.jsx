import React, {useState} from 'react'

function genId(){ return 'user_' + Math.random().toString(36).slice(2,9) }

export default function Auth({ onLogin }){
  const [mode, setMode] = useState('login') // login | register
  const [name,setName] = useState('')
  const [email,setEmail] = useState('')
  const [phone,setPhone] = useState('')
  const [password,setPassword] = useState('')

  const register = () => {
    if(!name||!phone||!password) return alert('Provide name, phone and password')
    const users = JSON.parse(localStorage.getItem('sdm_users')||'[]')
    if(users.find(u=>u.phone===phone)) return alert('Phone already registered')
    const u = { id: genId(), name, email, phone, password, account_type:'Individual', verified:true, created_at:Date.now() }
    users.push(u)
    localStorage.setItem('sdm_users', JSON.stringify(users))
    alert('Registered. Logging in...')
    onLogin(u)
  }

  const login = () => {
    const users = JSON.parse(localStorage.getItem('sdm_users')||'[]')
    const u = users.find(x=>x.phone===phone && x.password===password)
    if(!u) return alert('Invalid credentials')
    onLogin(u)
  }

  return (
    <div style={{maxWidth:480}}>
      <div style={{display:'flex',gap:8,marginBottom:12}}>
        <button className="btn" onClick={()=>setMode('login')}>Login</button>
        <button className="btn" onClick={()=>setMode('register')}>Register</button>
      </div>

      {mode==='register' ? (
        <div>
          <label className="small">Name</label>
          <input value={name} onChange={e=>setName(e.target.value)} />
          <label className="small">Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} />
          <label className="small">Phone</label>
          <input value={phone} onChange={e=>setPhone(e.target.value)} />
          <label className="small">Password</label>
          <input value={password} onChange={e=>setPassword(e.target.value)} type="password" />
          <div style={{marginTop:10}}><button className="btn" onClick={register}>Create account</button></div>
        </div>
      ) : (
        <div>
          <label className="small">Phone</label>
          <input value={phone} onChange={e=>setPhone(e.target.value)} />
          <label className="small">Password</label>
          <input value={password} onChange={e=>setPassword(e.target.value)} type="password" />
          <div style={{marginTop:10}}><button className="btn" onClick={login}>Login</button></div>
        </div>
      )}
    </div>
  )
}
