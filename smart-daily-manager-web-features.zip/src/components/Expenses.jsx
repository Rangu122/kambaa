import React, {useState, useEffect, useRef} from 'react'

export default function Expenses({ user }){
  const key = 'sdm_expenses_' + user.id
  const [items,setItems] = useState([])
  const [amount,setAmount] = useState('')
  const [category,setCategory] = useState('')
  const [desc,setDesc] = useState('')
  const fileRef = useRef()

  useEffect(()=> {
    const data = JSON.parse(localStorage.getItem(key)||'[]')
    setItems(data)
  },[])

  useEffect(()=> localStorage.setItem(key, JSON.stringify(items)), [items])

  const add = async () => {
    if(!amount) return alert('Enter amount')
    let receipt = null
    const f = fileRef.current?.files?.[0]
    if(f){
      receipt = await toBase64(f)
    }
    setItems([{id:Date.now().toString(), amount:parseFloat(amount), category, desc, receipt, createdAt:Date.now()}, ...items])
    setAmount(''); setCategory(''); setDesc('')
    if(fileRef.current) fileRef.current.value = ''
  }

  const remove = (id) => setItems(items.filter(i=>i.id!==id))

  return (
    <div>
      <h2>Daily Expenses</h2>
      <div className="row" style={{marginTop:8}}>
        <div className="col"><input placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} /></div>
        <div style={{width:160}}><input placeholder="Category" value={category} onChange={e=>setCategory(e.target.value)} /></div>
        <div style={{width:220}}><input placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)} /></div>
        <div><input ref={fileRef} type="file" /></div>
        <div><button className="btn" onClick={add}>Add</button></div>
      </div>

      <div style={{marginTop:12}}>
        {items.length===0 && <div className="muted">No expenses yet</div>}
        {items.map(it=>(
          <div key={it.id} className="list-item">
            <div>
              <div style={{fontWeight:600}}>₹{it.amount.toFixed(2)} · <span className="muted">{it.category}</span></div>
              <div className="small">{it.desc}</div>
              {it.receipt && <img src={it.receipt} style={{maxWidth:180,marginTop:8,borderRadius:8}} />}
            </div>
            <div>
              <button onClick={()=>remove(it.id)} style={{color:'red'}}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function toBase64(file){
  return new Promise((res,rej)=>{
    const reader = new FileReader()
    reader.onload = () => res(reader.result)
    reader.onerror = rej
    reader.readAsDataURL(file)
  })
}
