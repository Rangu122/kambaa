import React, {useState, useEffect} from 'react'

export default function Groceries({ user }){
  const key = 'sdm_groceries_' + user.id
  const [list,setList] = useState([])
  const [name,setName] = useState('')
  const [qty,setQty] = useState('')
  const [cat,setCat] = useState('')

  useEffect(()=> {
    const data = JSON.parse(localStorage.getItem(key)||'[]')
    setList(data)
  },[])

  useEffect(()=> localStorage.setItem(key, JSON.stringify(list)), [list])

  const add = () => {
    if(!name) return
    setList([{id:Date.now().toString(), name, quantity:qty, category:cat, purchased:false, createdAt:Date.now()}, ...list])
    setName(''); setQty(''); setCat('')
  }
  const toggle = (id) => setList(list.map(i=> i.id===id ? {...i,purchased:!i.purchased} : i))
  const removeItem = (id) => setList(list.filter(i=>i.id!==id))

  return (
    <div>
      <h2>Grocery Lists</h2>
      <div className="row" style={{marginTop:8}}>
        <div className="col"><input placeholder="Item name" value={name} onChange={e=>setName(e.target.value)} /></div>
        <div style={{width:120}}><input placeholder="Qty" value={qty} onChange={e=>setQty(e.target.value)} /></div>
        <div style={{width:140}}><input placeholder="Category" value={cat} onChange={e=>setCat(e.target.value)} /></div>
        <div><button className="btn" onClick={add}>Add</button></div>
      </div>

      <div style={{marginTop:12}}>
        {list.length===0 && <div className="muted">No items yet</div>}
        {list.map(it=>(
          <div key={it.id} className="list-item">
            <div>
              <div style={{fontWeight:600}}>{it.name} {it.quantity ? `(${it.quantity})` : ''}</div>
              <div className="muted small">{it.category}</div>
            </div>
            <div style={{display:'flex',gap:8}}>
              <button onClick={()=>toggle(it.id)} className="small">{it.purchased ? 'Unmark' : 'Mark Purchased'}</button>
              <button onClick={()=>removeItem(it.id)} className="small" style={{color:'red'}}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
