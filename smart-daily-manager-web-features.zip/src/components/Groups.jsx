import React, {useState, useEffect} from 'react'

export default function Groups({ user }){
  const key = 'sdm_groups_' + user.id
  const [groups,setGroups] = useState([])
  const [name,setName] = useState('')
  useEffect(()=> setGroups(JSON.parse(localStorage.getItem(key)||'[]')), [])
  useEffect(()=> localStorage.setItem(key, JSON.stringify(groups)), [groups])
  const create = () => {
    if(!name) return
    setGroups([{id:Date.now().toString(), name, members:[user.id], shared:[], createdAt:Date.now()}, ...groups])
    setName('')
  }
  const view = (g) => {
    alert('Shared items:\n' + (g.shared||[]).map(s=>`${s.type} - ${s.payload?.desc || s.payload?.name || s.payload?.title || ''}`).join('\n') )
  }
  return (
    <div>
      <h2>Groups (Family Sharing)</h2>
      <div style={{display:'flex',gap:8,marginTop:8}}>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Group name" />
        <button className="btn" onClick={create}>Create</button>
      </div>
      <div style={{marginTop:12}}>
        {groups.length===0 && <div className="muted">No groups yet</div>}
        {groups.map(g=>(
          <div key={g.id} className="list-item">
            <div>
              <div style={{fontWeight:600}}>{g.name}</div>
              <div className="small muted">Members: {g.members.length}</div>
            </div>
            <div style={{display:'flex',gap:8}}>
              <button onClick={()=>view(g)}>View Shared</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
