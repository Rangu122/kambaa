import React, {useState, useEffect} from 'react'

export default function Notes({ user }){
  const key = 'sdm_notes_' + user.id
  const [notes,setNotes] = useState([])
  const [title,setTitle] = useState('')
  const [content,setContent] = useState('')
  const [reminder,setReminder] = useState('')

  useEffect(()=> {
    const data = JSON.parse(localStorage.getItem(key)||'[]')
    setNotes(data)
  },[])

  useEffect(()=> localStorage.setItem(key, JSON.stringify(notes)), [notes])

  const add = () => {
    if(!title) return
    setNotes([{id:Date.now().toString(), title, content, reminder: reminder || null, createdAt:Date.now()}, ...notes])
    setTitle(''); setContent(''); setReminder('')
  }
  const remove = (id) => setNotes(notes.filter(n=>n.id!==id))

  return (
    <div>
      <h2>Notes & Reminders</h2>
      <div style={{display:'grid',gridTemplateColumns:'1fr 220px',gap:8,marginTop:8}}>
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" />
        <input value={reminder} onChange={e=>setReminder(e.target.value)} placeholder="Reminder (YYYY-MM-DD HH:MM)" />
        <textarea value={content} onChange={e=>setContent(e.target.value)} placeholder="Note content" />
        <div><button className="btn" onClick={add}>Save Note</button></div>
      </div>

      <div style={{marginTop:12}}>
        {notes.length===0 && <div className="muted">No notes yet</div>}
        {notes.map(n=>(
          <div key={n.id} className="list-item">
            <div>
              <div style={{fontWeight:600}}>{n.title}</div>
              <div className="small">{n.content}</div>
              {n.reminder && <div className="muted small">Reminder: {n.reminder}</div>}
            </div>
            <div><button style={{color:'red'}} onClick={()=>remove(n.id)}>Delete</button></div>
          </div>
        ))}
      </div>
    </div>
  )
}
