import React from 'react'
export default function Profile({ user, onLogout }){
  return (
    <div>
      <h2>Profile</h2>
      <div style={{marginTop:8}}>
        <div><strong>Name:</strong> {user.name}</div>
        <div><strong>Phone:</strong> {user.phone}</div>
        <div><strong>Email:</strong> {user.email || '—'}</div>
        <div style={{marginTop:8}}><button className="btn" onClick={onLogout}>Logout</button></div>
      </div>
    </div>
  )
}
