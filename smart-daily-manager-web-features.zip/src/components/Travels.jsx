import React, {useState, useEffect, useRef} from 'react'

export default function Travels({ user }){
  const key = 'sdm_travels_' + user.id
  const [list,setList] = useState([])
  const [dest,setDest] = useState('')
  const [start,setStart] = useState('')
  const [end,setEnd] = useState('')
  const [purpose,setPurpose] = useState('')
  const fileRef = useRef()

  useEffect(()=> {
    const data = JSON.parse(localStorage.getItem(key)||'[]')
    setList(data)
  },[])

  useEffect(()=> localStorage.setItem(key, JSON.stringify(list)), [list])

  const add = async () => {
    let receipt = null
    const f = fileRef.current?.files?.[0]
    if(f){
      receipt = await toBase64(f)
    }
    setList([{id:Date.now().toString(), destination:dest, start_date:start, end_date:end, purpose, receipt, createdAt:Date.now()}, ...list])
    setDest(''); setStart(''); setEnd(''); setPurpose('')
    if(fileRef.current) fileRef.current.value = ''
  }
  const remove = (id) => setList(list.filter(i=>i.id!==id))

  return (
    <div>
      <h2>Travel History</h2>
      <div className="row" style={{marginTop:8}}>
        <div className="col"><input placeholder="Destination" value={dest} onChange={e=>setDest(e.target.value)} /></div>
        <div style={{width:160}}><input placeholder="Start date" value={start} onChange={e=>setStart(e.target.value)} /></div>
        <div style={{width:160}}><input placeholder="End date" value={end} onChange={e=>setEnd(e.target.value)} /></div>
        <div style={{width:200}}><input placeholder="Purpose" value={purpose} onChange={e=>setPurpose(e.target.value)} /></div>
        <div><input ref={fileRef} type="file" /></div>
        <div><button className="btn" onClick={add}>Add</button></div>
      </div>

      <div style={{marginTop:12}}>
        {list.length===0 && <div className="muted">No travels yet</div>}
        {list.map(it=>(
          <div key={it.id} className="list-item">
            <div>
              <div style={{fontWeight:600}}>{it.destination} <span className="muted small">{it.start_date} → {it.end_date}</span></div>
              <div className="small">{it.purpose}</div>
              {it.receipt && <img src={it.receipt} style={{maxWidth:160,marginTop:8,borderRadius:8}} />}
            </div>
            <div><button style={{color:'red'}} onClick={()=>remove(it.id)}>Delete</button></div>
          </div>
        ))}
      </div>
    </div>
  )
}

function toBase64(file){
  return new Promise((res,rej)=>{
    const reader = new FileReader()
    reader.onload = () => res(reader.result)
    reader.onerror = rej
    reader.readAsDataURL(file)
  })
}
